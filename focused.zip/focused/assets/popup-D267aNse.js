import{t as R,r as b,j as r,n as Te,v as De,B as We,o as Ue,C as Ie,q as Ve,s as Ge}from"./rotatingPlaceholders-_Ey_oVJ-.js";const Be=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h2",key:"tvwodi"}],["path",{d:"M20 8v11a2 2 0 0 1-2 2h-2",key:"1gkqxj"}],["path",{d:"m9 15 3-3 3 3",key:"1pd0qc"}],["path",{d:"M12 12v9",key:"192myk"}]],Je=R("archive-restore",Be);const Qe=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8",key:"1s80jp"}],["path",{d:"M10 12h4",key:"a56b0p"}]],Ke=R("archive",Qe);const Ze=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],ea=R("arrow-right",Ze);const aa=[["path",{d:"M10 18H5a3 3 0 0 1-3-3v-1",key:"ru65g8"}],["path",{d:"M14 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"e30een"}],["path",{d:"M20 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"2ahx8o"}],["path",{d:"m7 21 3-3-3-3",key:"127cv2"}],["rect",{x:"14",y:"14",width:"8",height:"8",rx:"2",key:"1b0bso"}],["rect",{x:"2",y:"2",width:"8",height:"8",rx:"2",key:"1x09vl"}]],ra=R("combine",aa);const ta=[["line",{x1:"12",x2:"18",y1:"12",y2:"18",key:"1rg63v"}],["line",{x1:"12",x2:"18",y1:"18",y2:"12",key:"ebkxgr"}],["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]],oa=R("copy-x",ta);const sa=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],me=R("loader-circle",sa);const ia=[["path",{d:"M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8",key:"12jkf8"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}],["path",{d:"M19 16v6",key:"tddt3s"}],["path",{d:"M16 19h6",key:"xwg31i"}]],na=R("mail-plus",ia);const la=[["path",{d:"M12 17v5",key:"bb1du9"}],["path",{d:"M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",key:"1nkz8b"}]],ca=R("pin",la);const da=[["path",{d:"M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",key:"w46dr5"}]],pa=R("puzzle",da);const ba=[["path",{d:"M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z",key:"117uat"}],["path",{d:"M6 12h16",key:"s4cdu5"}]],ua=R("send-horizontal",ba);const ga=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],ma=R("settings",ga);const fa=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],xa=R("shield-check",fa);const ha=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]],$a=R("sparkles",ha);const ya=[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]],va=R("undo-2",ya);const za=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],wa=R("x",za),ka={sm:{borderRadius:32,borderWidth:1,width:70,height:36},md:{borderRadius:16,borderWidth:1},line:{borderRadius:16,borderWidth:1},"pulse-outside":{borderRadius:16,borderWidth:1},"pulse-inner":{borderRadius:16,borderWidth:1}},ja={sm:{dark:{strokeOpacity:.46,innerOpacity:.24,bloomOpacity:.38,innerShadow:"rgba(255, 255, 255, 0.3)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.3,bloomOpacity:.16,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.8}},md:{dark:{strokeOpacity:.26,innerOpacity:.42,bloomOpacity:.24,innerShadow:"rgba(255, 255, 255, 0.27)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.26,bloomOpacity:.34,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.5}},line:{dark:{strokeOpacity:1.14,innerOpacity:.7,bloomOpacity:.8,innerShadow:"rgba(255, 255, 255, 0.1)",saturation:1.2},light:{strokeOpacity:.16,innerOpacity:.32,bloomOpacity:.3,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.95}},"pulse-outside":{dark:{strokeOpacity:.94,innerOpacity:.34,bloomOpacity:.3,innerShadow:"transparent",saturation:1.2,brightness:1.9,hairlineOpacity:0},light:{strokeOpacity:1.96,innerOpacity:1.04,bloomOpacity:.42,innerShadow:"transparent",saturation:.6,brightness:1.7,hairlineOpacity:0}},"pulse-inner":{dark:{strokeOpacity:1.54,innerOpacity:.44,bloomOpacity:.66,innerShadow:"transparent",saturation:1.2,brightness:.75},light:{strokeOpacity:.32,innerOpacity:.4,bloomOpacity:.8,innerShadow:"transparent",saturation:.75,brightness:1.3}}},oe={colorful:{border:[{color:"rgb(255, 50, 100)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(40, 140, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(50, 200, 80)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(30, 185, 170)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(100, 70, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(40, 140, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 120, 40)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(240, 50, 180)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(180, 40, 240)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 60, 80)",secondary:"rgba(40, 190, 180, 0.98)"},spikeLt:{primary:"rgb(200, 30, 60)",secondary:"rgb(20, 150, 140)"}},mono:{border:[{color:"rgb(180, 180, 180)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(140, 140, 140)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(160, 160, 160)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(130, 130, 130)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(170, 170, 170)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(150, 150, 150)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(190, 190, 190)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(145, 145, 145)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(165, 165, 165)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(200, 200, 200)",secondary:"rgb(170, 170, 170)"},spikeLt:{primary:"rgb(80, 80, 80)",secondary:"rgb(120, 120, 120)"}},ocean:{border:[{color:"rgb(100, 80, 220)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(60, 120, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(80, 100, 200)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(50, 140, 220)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(120, 80, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(70, 130, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(140, 100, 240)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(90, 110, 230)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(130, 70, 255)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(100, 120, 255)",secondary:"rgba(130, 100, 220, 0.98)"},spikeLt:{primary:"rgb(60, 60, 180)",secondary:"rgb(80, 100, 200)"}},sunset:{border:[{color:"rgb(255, 80, 50)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(255, 160, 40)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(255, 120, 60)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(255, 200, 50)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(255, 100, 80)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(255, 180, 60)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 60, 60)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(255, 140, 50)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(255, 90, 70)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 140, 80)",secondary:"rgba(255, 100, 60, 0.98)"},spikeLt:{primary:"rgb(200, 80, 40)",secondary:"rgb(220, 120, 30)"}}},qe={colorful:{border:[{color:"rgb(50, 200, 80)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(30, 185, 170)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 120, 40)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(100, 70, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(240, 50, 180)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(180, 40, 240)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(40, 140, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 50, 100)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(50, 200, 80, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(30, 185, 170, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 120, 40, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(100, 70, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(240, 50, 180, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(180, 40, 240, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(40, 140, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 50, 100, 0.3)",pos:"100% 27%",size:"11px 12px"}]},mono:{border:[{color:"rgb(160, 160, 160)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(140, 140, 140)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(180, 180, 180)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(150, 150, 150)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(170, 170, 170)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(155, 155, 155)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(145, 145, 145)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(165, 165, 165)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(160, 160, 160, 0.25)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(140, 140, 140, 0.22)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(180, 180, 180, 0.17)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(150, 150, 150, 0.17)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(170, 170, 170, 0.15)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(155, 155, 155, 0.20)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(145, 145, 145, 0.15)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(165, 165, 165, 0.15)",pos:"100% 27%",size:"11px 12px"}]},ocean:{border:[{color:"rgb(60, 140, 200)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(50, 120, 180)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(100, 80, 220)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(80, 100, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(120, 70, 240)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(90, 80, 220)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(70, 110, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(110, 90, 230)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(60, 140, 200, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(50, 120, 180, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(100, 80, 220, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(80, 100, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(120, 70, 240, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(90, 80, 220, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(70, 110, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(110, 90, 230, 0.3)",pos:"100% 27%",size:"11px 12px"}]},sunset:{border:[{color:"rgb(255, 180, 50)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(255, 150, 40)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 80, 60)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(255, 100, 80)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(255, 60, 80)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(255, 120, 60)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(255, 200, 50)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 90, 70)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(255, 180, 50, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(255, 150, 40, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 80, 60, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(255, 100, 80, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(255, 60, 80, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(255, 120, 60, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(255, 200, 50, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 90, 70, 0.3)",pos:"100% 27%",size:"11px 12px"}]}};function Na(o){return qe[o].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Wa(o){return qe[o].inner.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Ca(o){return oe[o].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Ha(o){const e=oe[o],a=o==="mono"?.225:.45;return e.border.map(t=>{const n=t.color.replace("rgb(","rgba(").replace(")",`, ${a})`);return`radial-gradient(ellipse ${t.size.split(" ").map(c=>{const d=parseInt(c);return`${Math.round(d*.9)}px`}).join(" ")} at ${t.pos}, ${n}, transparent)`}).join(`,
    `)}function Xa(o,e){const a=oe[o];return e?a.spike:a.spikeLt}const Ya={colorful:{dark:[{color:"rgb(255, 50, 100)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 180, 220)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 160, 30)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(240, 50, 180)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(30, 185, 170)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(255, 50, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 140, 255)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(30, 185, 170)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(255, 120, 40)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(240, 50, 180)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},mono:{dark:[{color:"rgb(200, 200, 200)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(170, 170, 170)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(155, 155, 155)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(185, 185, 185)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(165, 165, 165)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(180, 180, 180)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(160, 160, 160)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(175, 175, 175)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(190, 190, 190)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(100, 100, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(80, 80, 80)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(90, 90, 90)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(70, 70, 70)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(85, 85, 85)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(95, 95, 95)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(75, 75, 75)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(105, 105, 105)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(65, 65, 65)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},ocean:{dark:[{color:"rgb(100, 80, 220)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(60, 120, 255)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(80, 100, 200)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(130, 70, 255)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(70, 130, 255)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(120, 80, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(90, 110, 230)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(110, 90, 240)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(140, 100, 255)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(80, 60, 200)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(50, 100, 220)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(70, 90, 190)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(110, 60, 220)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(60, 110, 230)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 240)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(80, 100, 210)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(90, 80, 225)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(120, 90, 245)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},sunset:{dark:[{color:"rgb(255, 100, 60)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(255, 180, 50)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(255, 140, 70)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(255, 80, 80)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 200, 60)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(255, 120, 50)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(255, 160, 80)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(255, 90, 60)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(255, 70, 70)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(220, 80, 40)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(230, 150, 30)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(210, 110, 50)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(200, 60, 60)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(220, 170, 40)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(210, 100, 30)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(230, 130, 60)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(190, 70, 50)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(180, 50, 50)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]}};function Sa(o,e,a){return Ya[o][e?"dark":"light"].map(t=>{const n=t.offsetX===0?"":t.offsetX>0?` + ${t.offsetX}px`:` - ${Math.abs(t.offsetX)}px`,c=t.offsetY===0?"":t.offsetY>0?` + ${t.offsetY}px`:` - ${Math.abs(t.offsetY)}px`;return`radial-gradient(ellipse calc(${t.sizeW}px * var(--beam-w-${a})) calc(${t.sizeH}px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%${n}) calc(100%${c}), ${t.color}, transparent)`}).join(`,
       `)}const Ma={colorful:[{color:"rgba(255, 50, 100, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(40, 180, 220, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(50, 200, 80, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(180, 40, 240, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 160, 30, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(100, 70, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(40, 140, 255, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(240, 50, 180, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(30, 185, 170, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],mono:[{color:"rgba(200, 200, 200, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(170, 170, 170, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(155, 155, 155, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(185, 185, 185, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(165, 165, 165, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(180, 180, 180, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(160, 160, 160, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(175, 175, 175, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(190, 190, 190, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],ocean:[{color:"rgba(100, 80, 220, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(60, 120, 255, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(80, 100, 200, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(130, 70, 255, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(70, 130, 255, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(120, 80, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(90, 110, 230, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(110, 90, 240, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(140, 100, 255, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],sunset:[{color:"rgba(255, 100, 60, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(255, 180, 50, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(255, 140, 70, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(255, 80, 80, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 200, 60, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(255, 120, 50, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(255, 160, 80, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(255, 90, 60, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(255, 70, 70, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}]};function Oa(o,e){return Ma[o].map(a=>{const t=a.offsetX===0?"":a.offsetX>0?` + ${a.offsetX}px`:` - ${Math.abs(a.offsetX)}px`,n=a.offsetY===0?"":` - ${Math.abs(a.offsetY)}px`;return`radial-gradient(ellipse calc(${a.sizeW}px * var(--beam-w-${e})) calc(${a.sizeH}px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%${t}) calc(100%${n}), ${a.color}, transparent)`}).join(`,
    `)}const Fa={colorful:{dark:{spikes:[{color1:"rgb(100, 70, 255)",color2:"rgba(100, 70, 255, 1)"},{color1:"rgba(255, 170, 40, 0.59)",color2:"rgba(255, 170, 40, 0.29)"},{color1:"rgb(50, 200, 100)",color2:"rgba(50, 200, 100, 1)"},{color1:"rgba(200, 50, 240, 0.91)",color2:"rgba(200, 50, 240, 0.45)"},{color1:"rgb(40, 140, 255)",color2:"rgba(40, 140, 255, 1)"}]},light:{spikes:[{color1:"rgb(80, 50, 200)",color2:"rgba(80, 50, 200, 0.8)"},{color1:"rgba(210, 130, 0, 0.7)",color2:"rgba(210, 130, 0, 0.46)"},{color1:"rgb(30, 160, 70)",color2:"rgba(30, 160, 70, 0.82)"},{color1:"rgb(160, 30, 190)",color2:"rgba(160, 30, 190, 0.7)"},{color1:"rgb(30, 100, 200)",color2:"rgba(30, 100, 200, 0.78)"}]}},mono:{dark:{spikes:[{color1:"rgb(200, 200, 200)",color2:"rgba(200, 200, 200, 1)"},{color1:"rgba(180, 180, 180, 0.59)",color2:"rgba(180, 180, 180, 0.29)"},{color1:"rgb(190, 190, 190)",color2:"rgba(190, 190, 190, 1)"},{color1:"rgba(170, 170, 170, 0.91)",color2:"rgba(170, 170, 170, 0.45)"},{color1:"rgb(185, 185, 185)",color2:"rgba(185, 185, 185, 1)"}]},light:{spikes:[{color1:"rgb(80, 80, 80)",color2:"rgba(80, 80, 80, 0.8)"},{color1:"rgba(100, 100, 100, 0.7)",color2:"rgba(100, 100, 100, 0.46)"},{color1:"rgb(70, 70, 70)",color2:"rgba(70, 70, 70, 0.82)"},{color1:"rgb(90, 90, 90)",color2:"rgba(90, 90, 90, 0.7)"},{color1:"rgb(85, 85, 85)",color2:"rgba(85, 85, 85, 0.78)"}]}},ocean:{dark:{spikes:[{color1:"rgb(100, 80, 255)",color2:"rgb(100, 80, 255)"},{color1:"rgba(80, 130, 220, 0.59)",color2:"rgba(80, 130, 220, 0.29)"},{color1:"rgb(60, 100, 255)",color2:"rgb(60, 100, 255)"},{color1:"rgba(90, 120, 200, 0.91)",color2:"rgba(90, 120, 200, 0.45)"},{color1:"rgb(120, 90, 255)",color2:"rgb(120, 90, 255)"}]},light:{spikes:[{color1:"rgb(50, 40, 180)",color2:"rgba(50, 40, 180, 0.8)"},{color1:"rgba(40, 80, 200, 0.7)",color2:"rgba(40, 80, 200, 0.46)"},{color1:"rgb(30, 50, 190)",color2:"rgba(30, 50, 190, 0.82)"},{color1:"rgb(60, 90, 180)",color2:"rgba(60, 90, 180, 0.7)"},{color1:"rgb(70, 60, 200)",color2:"rgba(70, 60, 200, 0.78)"}]}},sunset:{dark:{spikes:[{color1:"rgb(255, 100, 80)",color2:"rgb(255, 100, 80)"},{color1:"rgba(255, 150, 80, 0.59)",color2:"rgba(255, 150, 80, 0.29)"},{color1:"rgb(255, 80, 60)",color2:"rgb(255, 80, 60)"},{color1:"rgba(255, 120, 50, 0.91)",color2:"rgba(255, 120, 50, 0.45)"},{color1:"rgb(255, 140, 70)",color2:"rgb(255, 140, 70)"}]},light:{spikes:[{color1:"rgb(200, 60, 30)",color2:"rgba(200, 60, 30, 0.8)"},{color1:"rgba(220, 100, 20, 0.7)",color2:"rgba(220, 100, 20, 0.46)"},{color1:"rgb(180, 40, 20)",color2:"rgba(180, 40, 20, 0.82)"},{color1:"rgb(210, 80, 10)",color2:"rgba(210, 80, 10, 0.7)"},{color1:"rgb(190, 70, 30)",color2:"rgba(190, 70, 30, 0.78)"}]}}};function $e(o,e){const a=o.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*[\d.]+\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${e})`;const t=o.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return t?`rgba(${t[1]}, ${t[2]}, ${t[3]}, ${e})`:o}function te(o,e){const a=o.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${(parseFloat(a[4])*e).toFixed(2)})`;const t=o.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return t?`rgba(${t[1]}, ${t[2]}, ${t[3]}, ${e.toFixed(2)})`:o}function Ra(o,e,a){const t=Xa(o,e),n=Fa[o][e?"dark":"light"],c=o==="mono",d=c?.14:1,p=c?te(t.primary,.14):t.primary,m=c?te(t.primary,.09):t.primary,g=c?te(t.secondary,.12):t.secondary,h=c?$e(t.secondary,.06):$e(t.secondary,.49),l=n.spikes.map(X=>c?{color1:te(X.color1,d),color2:te(X.color2,d*.7)}:X),s=c?"12px":"0.8px",f=c?"14px":"2px",j=c?"12px":"1.2px",$=c?"10px":"0.6px",w=c?"42px":"92px",H=c?"38px":"72px",N=c?"40px":"85px",x=c?"32px":"60px",y=c?"12px":"1px",v=c?"rgba(255, 255, 255, 0.5)":"rgba(255, 255, 255, 1)",z=c?"rgba(255, 255, 255, 0.45)":"rgba(255, 255, 255, 0.9)",Y=c?"rgba(255, 255, 255, 0.25)":"rgba(255, 255, 255, 0.5)",k=c?"rgba(255, 255, 255, 0.15)":"rgba(255, 255, 255, 0.3)",O=c?"rgba(255, 255, 255, 0.06)":"rgba(255, 255, 255, 0.12)",M=c?"rgba(255, 255, 255, 0.015)":"rgba(255, 255, 255, 0.03)";if(e)return`radial-gradient(ellipse calc(${s} * var(--beam-spike-${a})) calc(${w} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${p}, ${m} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${g}, ${h} 50%, transparent 95%),
       radial-gradient(ellipse calc(${f} * (2 - var(--beam-spike-${a}))) calc(${H} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${l[0].color1}, ${l[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${l[1].color1}, ${l[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${j} * (2 - var(--beam-spike2-${a}))) calc(${N} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${l[2].color1}, ${l[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${l[3].color1}, ${l[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${$} * (2 - var(--beam-spike-${a}))) calc(${x} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${l[4].color1}, ${l[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(21px * var(--beam-spike-${a})) calc(15px * var(--beam-spike2-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100% + 1px), ${v} 0%, ${z} 20%, ${Y} 50%, transparent 100%),
       radial-gradient(ellipse calc(42px * var(--beam-w-${a})) calc(40px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) 100%, ${k} 0%, ${O} 25%, ${M} 55%, transparent 80%)`;{const X=c?te(t.primary,.11):$e(t.primary,.85),T=c?te(t.secondary,.09):$e(t.secondary,.7);return`radial-gradient(ellipse calc(${s} * var(--beam-spike-${a})) calc(${w} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${p}, ${X} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${g}, ${T} 50%, transparent 95%),
       radial-gradient(ellipse calc(${f} * (2 - var(--beam-spike-${a}))) calc(${H} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${l[0].color1}, ${l[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${l[1].color1}, ${l[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${j} * (2 - var(--beam-spike2-${a}))) calc(${N} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${l[2].color1}, ${l[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${l[3].color1}, ${l[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${y} * (2 - var(--beam-spike-${a}))) calc(${x} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${l[4].color1}, ${l[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(50px * var(--beam-w-${a})) calc(32px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100%), rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.18) 30%, rgba(0, 0, 0, 0.03) 60%, transparent 85%)`}}const Ae=[{region:1,quad:"tl"},{region:2,quad:"tl"},{region:3,quad:"bl"},{region:1,quad:"bl"},{region:2,quad:"br"},{region:3,quad:"br"},{region:1,quad:"tr"},{region:2,quad:"tr"},{region:3,quad:"tr"}],_a=[[65,35],[55,30],[35,65],[15,30],[173,28],[80,22],[69,28],[22,38],[47,44]],qa=[{ci:0,region:1,quad:"tl",w:84,h:48},{ci:1,region:2,quad:"tl",w:72,h:42},{ci:2,region:3,quad:"bl",w:48,h:84},{ci:4,region:2,quad:"br",w:216,h:38},{ci:5,region:3,quad:"br",w:102,h:31},{ci:6,region:1,quad:"tr",w:89,h:38},{ci:8,region:3,quad:"tr",w:62,h:58}],Se=[{ci:0,region:1,quad:"tl",w:80,h:19,x:"27%",y:"0%"},{ci:6,region:2,quad:"tr",w:74,h:11,x:"73%",y:"-1%"},{ci:7,region:3,quad:"tr",w:15,h:44,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:19,h:38,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:84,h:13,x:"67%",y:"100%"},{ci:1,region:3,quad:"bl",w:60,h:21,x:"24%",y:"101%"},{ci:2,region:1,quad:"bl",w:17,h:40,x:"0%",y:"60%"},{ci:3,region:2,quad:"tl",w:13,h:32,x:"-1%",y:"28%"}],Aa=[{ci:0,region:1,quad:"tl",w:110,h:30,x:"27%",y:"3%"},{ci:6,region:2,quad:"tr",w:100,h:20,x:"73%",y:"1%"},{ci:7,region:3,quad:"tr",w:26,h:62,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:30,h:56,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:120,h:22,x:"67%",y:"99%"},{ci:1,region:3,quad:"bl",w:88,h:32,x:"24%",y:"99%"},{ci:2,region:1,quad:"bl",w:28,h:58,x:"0%",y:"60%"}];function Pa(o,e,a){const t=o.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/);return`rgba(${t?`${t[1]}, ${t[2]}, ${t[3]}`:"255, 255, 255"}, var(--bop-${e}-${a}))`}function Xe(o,e,a,t,n,c,d,p){return`radial-gradient(ellipse calc(${e}px * var(--bw${t}-${p}) * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${a}px * var(--bh${t}-${p}) * var(--bgh-${p}) * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at calc(${c} + var(--bx${t}-${p})) calc(${d} + var(--by${t}-${p})), ${Pa(o,n,p)}, transparent)`}function La(o,e){return oe[o].border.map((a,t)=>{const{region:n,quad:c}=Ae[t],[d,p]=a.pos.split(" "),[m,g]=a.size.split(" ").map(parseFloat);return Xe(a.color,m,g,n,c,d,p,e)}).join(`,
    `)}function Ea(o,e,a){const t=oe[o].border.map((p,m)=>{const{region:g,quad:h}=Ae[m],[l,s]=p.pos.split(" "),[f,j]=_a[m];return Xe(p.color,f,j,g,h,l,s,e)}),n=a?"255, 255, 255":"0, 0, 0",c=a?.18:.08,d=[["0%","0%","tl"],["100%","0%","tr"],["0%","100%","bl"],["100%","100%","br"]].map(([p,m,g])=>`radial-gradient(ellipse 60px 60px at ${p} ${m}, rgba(${n}, calc(${c} * var(--bop-${g}-${e}))), transparent 70%)`);return[...t,...d].join(`,
    `)}function Me(o,e,a){const t=oe[e].border;return o.map(n=>{const c=t[n.ci],[d,p]=c.pos.split(" ");return Xe(c.color,n.w,n.h,n.region,n.quad,n.x??d,n.y??p,a)}).join(`,
    `)}function Pe(o,e,a){const t=oe[e].border,n=+a.toFixed(3);return o.map(c=>{const d=t[c.ci],[p,m]=d.pos.split(" "),g=c.x??p,h=c.y??m,l=d.color.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/),s=l?`${l[1]}, ${l[2]}, ${l[3]}`:"255, 255, 255";return`radial-gradient(ellipse calc(${c.w}px * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${c.h}px * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at ${g} ${h}, rgba(${s}, ${n}), transparent)`}).join(`,
    `)}function fe(o){return`
[data-beam="${o}"][data-paused],
[data-beam="${o}"][data-paused]::after,
[data-beam="${o}"][data-paused]::before,
[data-beam="${o}"][data-paused] [data-beam-bloom] {
  animation-play-state: paused !important;
}`}function Le(o){const e=["bw1","bh1","bw2","bh2","bw3","bh3","bgh","bop-tl","bop-tr","bop-bl","bop-br"],a=["bx1","by1","bx2","by2","bx3","by3"],t=e.map(c=>`@property --${c}-${o} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}`).join(`

`),n=a.map(c=>`@property --${c}-${o} {
  syntax: "<length>";
  initial-value: 0px;
  inherits: true;
}`).join(`

`);return`${t}

${n}

@property --beam-opacity-${o} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-hue-${o} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}`}function Ye(o,e,a){const t=e==="dark",n=a/2.3;return o==="pulse-inner"?{sp:.28,dr:t?33:40,op:t?.48:.45,gh:t?.34:.22,bs:(t?1.9:2.6)*n,ss:(t?2.6:4.6)*n,ghs:(t?2.4:5.5)*n,huePeriod:16}:{sp:t?.28:.36,dr:t?14:19,op:t?.46:0,gh:t?.16:.58,bs:(t?2.3:3.7)*n,ss:(t?6.4:4.6)*n,ghs:(t?2.4:3.8)*n,huePeriod:14}}function Ta(o,e){const{sp:a,dr:t,op:n,gh:c,bs:d,ss:p,ghs:m}=e;return[{prop:`--bw1-${o}`,a:1-a,b:1+a*1.1,period:p*.9,delay:0,unit:""},{prop:`--bh1-${o}`,a:1+a*.9,b:1-a*.85,period:p*1.26,delay:0,unit:""},{prop:`--bx1-${o}`,a:-t,b:t*.9,period:d*1.6,delay:0,unit:"px"},{prop:`--by1-${o}`,a:t*.55,b:-t*.7,period:d*1.6,delay:0,unit:"px"},{prop:`--bw2-${o}`,a:1+a,b:1-a*.85,period:p*1.1,delay:0,unit:""},{prop:`--bh2-${o}`,a:1-a*.8,b:1+a*1.05,period:p*.81,delay:0,unit:""},{prop:`--bx2-${o}`,a:t*.8,b:-t*.9,period:d*1.88,delay:0,unit:"px"},{prop:`--by2-${o}`,a:-t,b:t*.65,period:d*1.88,delay:0,unit:"px"},{prop:`--bw3-${o}`,a:1-a*.6,b:1+a*1.15,period:p*.98,delay:0,unit:""},{prop:`--bh3-${o}`,a:1+a*.75,b:1-a,period:p*1.4,delay:0,unit:""},{prop:`--bx3-${o}`,a:-t*.6,b:t,period:d*1.45,delay:0,unit:"px"},{prop:`--by3-${o}`,a:-t*.85,b:t*.45,period:d*1.45,delay:0,unit:"px"},{prop:`--bgh-${o}`,a:1-c,b:1+c,period:m,delay:0,unit:""},{prop:`--bop-tl-${o}`,a:1-n,b:1,period:d,delay:0,unit:""},{prop:`--bop-tr-${o}`,a:1-n,b:1,period:d*1.32,delay:d*.28,unit:""},{prop:`--bop-bl-${o}`,a:1-n,b:1,period:d*.84,delay:d*.55,unit:""},{prop:`--bop-br-${o}`,a:1-n,b:1,period:d*1.58,delay:d*.83,unit:""}]}function Da(o,e,a,t,n,c){if(o!=="pulse-inner"&&o!=="pulse-outside")return null;const d=Ye(o,e,a);return{oscillators:Ta(c,d),hue:n?null:{prop:`--beam-hue-${c}`,range:360,period:d.huePeriod,continuous:!0}}}function ze(o,e,a){return`  animation: ${e}-${o} ${a}s ease forwards;`}function Ua(o){const{size:e}=o;return e==="line"?Ja(o):e==="sm"?Ia(o):e==="pulse-inner"?Ga(o):e==="pulse-outside"?Ba(o):Va(o)}function Ia(o){const{id:e,borderRadius:a,borderWidth:t,duration:n,strokeOpacity:c,innerOpacity:d,bloomOpacity:p,innerShadow:m,colorVariant:g,staticColors:h,brightness:l,saturation:s,hueRange:f,theme:j}=o,$=Math.max(0,a-t),w=g==="mono"?.5:1,H=c*w,N=d*w,x=p*w,y=h?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,v=h?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${f}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${f}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${f}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
}`,z=j==="dark",Y=z?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,k=Na(g),O=Wa(g),M=z?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`,X=`conic-gradient(
    from var(--beam-angle-${e}),
    transparent 0%, transparent 22%,
    rgba(255, 255, 255, 0.12) 28%, rgba(255, 255, 255, 0.4) 36%,
    white 46%, white 82%,
    rgba(255, 255, 255, 0.4) 88%, rgba(255, 255, 255, 0.12) 94%,
    transparent 97%, transparent 100%
  )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${n}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${n}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${$}px;
  padding: ${t}px;
  clip-path: inset(0 round ${a}px);
  background: ${Y},${k};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${H.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${y}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${O};
  box-shadow: inset 0 0 5px 1px ${m};
  -webkit-mask-image: ${X};
  -webkit-mask-composite: source-over;
  mask-image: ${X};
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${N.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${y}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${$}px;
  clip-path: inset(0 round ${a}px);
  background: ${M};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${t}px;
  filter: blur(8px) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${x.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${v}
${fe(e)}
`}function Va(o){const{id:e,borderRadius:a,borderWidth:t,duration:n,strokeOpacity:c,innerOpacity:d,bloomOpacity:p,innerShadow:m,colorVariant:g,staticColors:h,brightness:l,saturation:s,hueRange:f,theme:j}=o,$=Math.max(0,a-t),w=g==="mono"?.5:1,H=c*w,N=d*w,x=p*w,y=h?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,v=h?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${f}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${f}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${f}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
}`,z=j==="dark",Y=z?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,k=Ca(g),O=Ha(g),M=z?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${n}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${n}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${$}px;
  padding: ${t}px;
  clip-path: inset(0 round ${a}px);
  background: ${Y},${k};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${H.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${y}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${O};
  box-shadow: inset 0 0 9px 1px ${m};
  -webkit-mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${N.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${y}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${$}px;
  clip-path: inset(0 round ${a}px);
  background: ${M};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${t}px;
  filter: blur(8px) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${x.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${v}
${fe(e)}
`}function Ga(o){const{id:e,borderRadius:a,borderWidth:t,duration:n,strokeOpacity:c,innerOpacity:d,bloomOpacity:p,colorVariant:m,staticColors:g,brightness:h,saturation:l,hueRange:s,theme:f}=o,j=f==="dark",$=m==="mono"?.5:1,w=(c*$).toFixed(2),H=(d*$).toFixed(2),N=(p*$).toFixed(2),{op:x}=Ye("pulse-inner",f,n),y=8,v=h.toFixed(2),z=l.toFixed(2),Y=g?`filter: brightness(${v}) saturate(${z});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${v}) saturate(${z});`,k=g?`filter: blur(${y}px) brightness(${v}) saturate(${z});`:`filter: blur(${y}px) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${v}) saturate(${z});`,O=La(m,e),M=Ea(m,e,j),X=Pe(qa,m,1-x*.5);return`
${Le(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${ze(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${ze(e,"beam-fade-out",.5)}
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: ${t}px;
  clip-path: inset(0 round ${a}px);
  background: ${O};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${w} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${Y}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${M};
  -webkit-mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-over;
  mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${H} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${Y}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${X};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${t}px;
  pointer-events: none;
  z-index: 3;
  will-change: opacity;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${N} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${k}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${fe(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function Ba(o){const{id:e,borderRadius:a,duration:t,strokeOpacity:n,innerOpacity:c,bloomOpacity:d,colorVariant:p,staticColors:m,brightness:g,saturation:h,hueRange:l,theme:s,hairlineOpacity:f=0}=o,j=s==="dark",$=p==="mono"?.5:1,w=(n*$).toFixed(2),H=(c*$).toFixed(2),N=(d*$).toFixed(2),x=j?"70, 70, 70":"0, 0, 0",y=f.toFixed(2),v=`linear-gradient(rgba(${x}, ${y}), rgba(${x}, ${y}))`,{op:z}=Ye("pulse-outside",s,t),Y=.95,k=.9,O=j?3:6,M=j?22.5:15,X=g.toFixed(2),T=h.toFixed(2),ce=m?`filter: brightness(${X}) saturate(${T});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${X}) saturate(${T});`,P=`brightness(var(--beam-glow-brightness, ${X})) saturate(var(--beam-glow-saturate, ${T}))`,D=m?`filter: blur(var(--beam-core-blur, ${O}px)) ${P};`:`filter: blur(var(--beam-core-blur, ${O}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${P};`,de=m?`filter: blur(var(--beam-bloom-blur, ${M}px)) ${P};`:`filter: blur(var(--beam-bloom-blur, ${M}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${P};`,A=Me(Se,p,e),C=Me(Se,p,e),_=Pe(Aa,p,1-z*.5),V=f>0?`${A},
    ${v}`:A;return`
${Le(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: visible;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${ze(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${ze(e,"beam-fade-out",.5)}
}
${f>0?`
/* Idle hairline — painted above the (opaque) child in the inner 1px edge ring so
   it overlaps a standard inset component border exactly. */
[data-beam="${e}"]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${v};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
}
`:""}
[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${V};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${w} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${ce}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: -10px;
  z-index: -1;
  border-radius: ${a+10}px;
  background: ${C};
  transform: scale(${Y}, ${k});
  pointer-events: none;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${H} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${D}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: -30px;
  z-index: -1;
  border-radius: ${a+30}px;
  background: ${_};
  transform: scale(${Y}, ${k});
  pointer-events: none;
  will-change: transform;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${N} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${de}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${fe(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function Ja(o){const{id:e,borderRadius:a,borderWidth:t,duration:n,strokeOpacity:c,innerOpacity:d,bloomOpacity:p,innerShadow:m,colorVariant:g,staticColors:h,brightness:l,saturation:s,hueRange:f,theme:j}=o,$=Math.max(0,a-t),w=j==="dark",H=c,N=d,x=p,y=h?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,v=h?"":`animation: beam-hue-shift-bloom-${e} 8s ease-in-out infinite;`,z=h?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${f}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${f}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${f}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
}

@keyframes beam-hue-shift-bloom-${e} {
  0% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${f+10}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
  50% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) + ${f+10}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
  100% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${f+10}deg)) brightness(${l.toFixed(2)}) saturate(${s.toFixed(2)}); }
}`,Y=w?`radial-gradient(
        ellipse calc(24px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(255, 255, 255, 0.38) 0%,
        rgba(255, 255, 255, 0.12) 30%,
        transparent 65%
      )`:`radial-gradient(
        ellipse calc(35px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(0, 0, 0, 0.6) 0%,
        rgba(0, 0, 0, 0.25) 35%,
        transparent 70%
      )`,k=Sa(g,w,e),O=Oa(g,e),M=Ra(g,w,e),X=g==="mono"?"filter: blur(6px);":"";return`
@property --beam-x-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-w-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-h-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike2-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-edge-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-travel-${e} ${n}s linear infinite,
    beam-edge-fade-${e} ${n}s linear infinite,
    beam-breathe-${e} ${(n*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(n*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(n*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-travel-${e} ${n}s linear infinite,
    beam-edge-fade-${e} ${n}s linear infinite,
    beam-breathe-${e} ${(n*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(n*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(n*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${$}px;
  padding: ${t}px;
  clip-path: inset(0 round ${a}px);
  background: ${Y}, ${k};
  -webkit-mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${H.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${y}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${O};
  box-shadow: inset 0 0 9px 1px ${m};
  -webkit-mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${N.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${y}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${$}px;
  clip-path: inset(0 round ${a}px);
  padding: 0;
  -webkit-mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  -webkit-mask-composite: source-over;
  mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  mask-composite: add;
  background: ${M};
  ${X}
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${x.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${v}
}

@keyframes beam-travel-${e} {
  0%   { --beam-x-${e}: 0.06;  --beam-w-${e}: 0.5; }
  10%  { --beam-x-${e}: 0.15;  --beam-w-${e}: 0.8; }
  20%  { --beam-x-${e}: 0.25;  --beam-w-${e}: 1.1; }
  30%  { --beam-x-${e}: 0.35;  --beam-w-${e}: 1.3; }
  40%  { --beam-x-${e}: 0.44;  --beam-w-${e}: 1.45; }
  50%  { --beam-x-${e}: 0.5;   --beam-w-${e}: 1.5; }
  60%  { --beam-x-${e}: 0.56;  --beam-w-${e}: 1.45; }
  70%  { --beam-x-${e}: 0.65;  --beam-w-${e}: 1.3; }
  80%  { --beam-x-${e}: 0.75;  --beam-w-${e}: 1.1; }
  90%  { --beam-x-${e}: 0.85;  --beam-w-${e}: 0.8; }
  100% { --beam-x-${e}: 0.94;  --beam-w-${e}: 0.5; }
}

@keyframes beam-edge-fade-${e} {
  0%    { --beam-edge-${e}: 0; }
  12.5% { --beam-edge-${e}: 0; }
  32.5% { --beam-edge-${e}: 1; }
  67.5% { --beam-edge-${e}: 1; }
  87.5% { --beam-edge-${e}: 0; }
  100%  { --beam-edge-${e}: 0; }
}

@keyframes beam-breathe-${e} {
  0%, 100% { --beam-h-${e}: 0.8; }
  25%      { --beam-h-${e}: 1.25; }
  55%      { --beam-h-${e}: 0.85; }
  80%      { --beam-h-${e}: 1.3; }
}

@keyframes beam-spike-${e} {
  0%   { --beam-spike-${e}: 0.8; }
  25%  { --beam-spike-${e}: 1.3; }
  50%  { --beam-spike-${e}: 0.9; }
  75%  { --beam-spike-${e}: 1.4; }
  100% { --beam-spike-${e}: 0.8; }
}

@keyframes beam-spike2-${e} {
  0%   { --beam-spike2-${e}: 1.2; }
  25%  { --beam-spike2-${e}: 0.7; }
  50%  { --beam-spike2-${e}: 1.4; }
  75%  { --beam-spike2-${e}: 0.8; }
  100% { --beam-spike2-${e}: 1.2; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${z}
${fe(e)}
`}const we=new Set;let le=null,Ce=0;const Qa=1e3/30-2,Ka=Math.PI*2;function Oe(o){return(1-Math.cos(Ka*o))/2}function Ee(o){if(le=requestAnimationFrame(Ee),o-Ce<Qa)return;Ce=o;const e=o/1e3;we.forEach(({el:a,config:t})=>{for(const n of t.oscillators){const c=(e-n.delay)/n.period,d=n.a+(n.b-n.a)*Oe(c);a.style.setProperty(n.prop,n.unit==="px"?`${d.toFixed(2)}px`:d.toFixed(4))}if(t.hue){const{prop:n,range:c,period:d,continuous:p}=t.hue,m=p?e/d%1*c:-c+2*c*Oe(e/d);a.style.setProperty(n,`${m.toFixed(2)}deg`)}})}function Za(){le==null&&(Ce=0,le=requestAnimationFrame(Ee))}function er(){we.size===0&&le!=null&&(cancelAnimationFrame(le),le=null)}function ar(o,e){const a={el:o,config:e};return we.add(a),Za(),()=>{we.delete(a),er()}}function rr(){const[o,e]=b.useState(()=>typeof window>"u"||window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");return b.useEffect(()=>{if(typeof window>"u")return;const a=window.matchMedia("(prefers-color-scheme: dark)"),t=n=>{e(n.matches?"dark":"light")};return a.addEventListener("change",t),()=>a.removeEventListener("change",t)},[]),o}function tr(o,e){return o==="auto"?e:o}const He=b.forwardRef(function({children:o,size:e="md",colorVariant:a="colorful",theme:t="dark",staticColors:n=!1,duration:c,active:d=!0,borderRadius:p,brightness:m,saturation:g,hueRange:h=30,strength:l=1,className:s,style:f,onActivate:j,onDeactivate:$,onAnimationEnd:w,...H},N){const x=b.useId().replace(/:/g,"-"),y=rr(),v=b.useRef(null),[z,Y]=b.useState(d),[k,O]=b.useState(!1),[M,X]=b.useState(!0),[T,ce]=b.useState(null),[P,D]=b.useState({x:1,y:1});b.useEffect(()=>{if(p!=null)return;const W=v.current;if(!W)return;const F=()=>{const J=W.firstElementChild;if(!J)return;const be=getComputedStyle(J),Q=parseFloat(be.borderTopLeftRadius);!isNaN(Q)&&Q>0&&ce(Q)};F();const B=new MutationObserver(F);return B.observe(W,{childList:!0,subtree:!1}),()=>B.disconnect()},[p,o]),b.useEffect(()=>{d&&!z&&!k?Y(!0):!d&&z&&!k&&O(!0)},[d,z,k]),b.useEffect(()=>{const W=v.current;if(!W||typeof IntersectionObserver>"u")return;const F=new IntersectionObserver(B=>{for(const J of B)X(J.isIntersecting)},{rootMargin:"256px"});return F.observe(W),()=>F.disconnect()},[]),b.useEffect(()=>{if(e!=="pulse-outside"){D({x:1,y:1});return}const W=v.current;if(!W)return;const F=350,B=140,J=.35,be=4,Q=ie=>Math.max(J,Math.min(be,ie)),ue=()=>{const ie=W.firstElementChild;if(!ie)return;const re=ie.getBoundingClientRect();if(!re.width||!re.height)return;const ne=+Q(re.width/F).toFixed(3),E=+Q(re.height/B).toFixed(3);D(K=>K.x===ne&&K.y===E?K:{x:ne,y:E})};if(ue(),typeof ResizeObserver>"u")return;const xe=W.firstElementChild;if(!xe)return;const he=new ResizeObserver(ue);return he.observe(xe),()=>he.disconnect()},[e,o]);const de=b.useCallback(W=>{const F=W.animationName;F.includes("fade-out")?(Y(!1),O(!1),$?.()):F.includes("fade-in")&&j?.(),w?.(W)},[j,$,w]),A=tr(t,y),C=ja[e][A],_=ka[e],V=e==="pulse-inner"||e==="pulse-outside",pe=p??T??_.borderRadius,U=c??(e==="line"?3.1:V?2.3:1.96),I=g??C.saturation,L=m??C.brightness??1.3,G=e==="line"?Math.min(h,13):h,S=a==="mono"?!0:n,se=b.useMemo(()=>Ua({id:x,borderRadius:pe,borderWidth:_.borderWidth,duration:U,strokeOpacity:C.strokeOpacity,innerOpacity:C.innerOpacity,bloomOpacity:C.bloomOpacity,innerShadow:C.innerShadow,size:e,colorVariant:a,staticColors:S,brightness:L,saturation:I,hueRange:G,theme:A,hairlineOpacity:C.hairlineOpacity}),[x,pe,_.borderWidth,U,C.strokeOpacity,C.innerOpacity,C.bloomOpacity,C.innerShadow,C.hairlineOpacity,e,a,S,L,I,G,A]),ae=b.useMemo(()=>V?Da(e,A,U,G,S,x):null,[V,e,A,U,G,S,x]);b.useEffect(()=>{var W;if(!ae||!(z||k)||!M)return;const F=v.current;if(F&&!(typeof window<"u"&&(W=window.matchMedia)!=null&&W.call(window,"(prefers-reduced-motion: reduce)").matches))return ar(F,ae)},[ae,z,k,M]);const ke=b.useCallback(W=>{v.current=W,typeof N=="function"?N(W):N&&(N.current=W)},[N]),je={...f??{},"--beam-strength":Math.max(0,Math.min(1,l)),...e==="pulse-outside"?{"--pulse-glow-sx":P.x,"--pulse-glow-sy":P.y}:{}};return r.jsxs(r.Fragment,{children:[r.jsx("style",{children:se}),r.jsxs("div",{...H,ref:ke,"data-beam":x,"data-active":z&&!k?"":void 0,"data-fading":k?"":void 0,"data-paused":z&&!k&&!M?"":void 0,className:s,style:je,onAnimationEnd:de,children:[o,r.jsx("div",{"data-beam-bloom":!0})]})]})});function or({className:o,...e}){return r.jsxs("svg",{viewBox:"0 0 20 20",fill:"none",stroke:"currentColor",strokeWidth:"1.7",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",className:o,...e,children:[r.jsx("path",{d:"M7 4H4.75A1.75 1.75 0 0 0 3 5.75v8.5A1.75 1.75 0 0 0 4.75 16H7"}),r.jsx("path",{d:"M8.5 6.5h5M8.5 10h7M8.5 13.5h3.5"}),r.jsx("path",{d:"m13.5 4 2-1m0 14 2-1"})]})}function sr({windowId:o,disabled:e,acknowledged:a,onAcknowledge:t,onRunningChange:n,onMutation:c}){const[d,p]=b.useState(""),[m,g]=b.useState(!1),[h,l]=b.useState(!1),[s,f]=b.useState(null),j=Te(De),$=b.useRef(!1),w=b.useRef(n);w.current=n,b.useEffect(()=>()=>{$.current&&w.current(!1)},[]);const H=async()=>{const x=d.trim();if(!(!x||$.current||e)){if(!a&&!h){l(!0),f(null);return}h&&(l(!1),await t()),$.current=!0,g(!0),n(!0),f(null);try{let y=await chrome.permissions.contains({origins:["<all_urls>"]});if(!y)try{y=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{y=!1}const v=await chrome.runtime.sendMessage({type:"command",query:x,windowId:o,hasContentPermission:y});f(v??{error:"Something went wrong."}),["create_group","add_to_group","update_group","ungroup","remove_duplicates","merge_groups"].includes(v?.action||"")&&!v.error&&(p(""),await c?.().catch(()=>{}))}catch{f({error:"Command was interrupted. Try again."})}finally{$.current=!1,g(!1),n(!1)}}},N=async x=>{await chrome.runtime.sendMessage({type:"focusTab",tabId:x})};return r.jsxs("section",{className:"mt-4","aria-label":"Command bar",children:[r.jsx(He,{size:"line",colorVariant:"ocean",theme:"dark",strength:.35,active:m,className:"w-full focus-within:ring-2 focus-within:ring-ring/30","data-testid":"command-beam",children:r.jsxs("div",{className:"flex items-center gap-2 rounded-lg border border-border bg-muted/20 px-2.5 focus-within:border-ring",children:[r.jsx("input",{value:d,onChange:x=>p(x.target.value),onKeyDown:x=>{x.key==="Enter"&&H()},disabled:e||m,placeholder:j,"aria-label":"Command",className:"h-9 min-w-0 flex-1 bg-transparent text-xs outline-none placeholder:text-muted-foreground disabled:opacity-50"}),m?r.jsx(me,{className:"size-3.5 shrink-0 animate-spin text-muted-foreground"}):r.jsx("button",{type:"button",onClick:H,disabled:e||!d.trim(),title:"Send","aria-label":"Send",className:"flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&:not(:disabled)]:text-primary",children:r.jsx(ua,{className:"size-3.5"})})]})}),h&&r.jsx("p",{className:"mt-2 text-xs leading-snug text-muted-foreground","aria-live":"polite",children:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Press Enter again to continue."}),s&&r.jsxs("div",{className:`mt-2 flex items-start gap-2 text-xs ${s.error?"text-destructive":"text-muted-foreground"}`,"aria-live":"polite",children:[r.jsx("p",{className:"min-w-0 flex-1 leading-snug",children:s.error?s.error:s.action==="open_tab"?`Jumped to “${s.tabTitle}”`:s.action==="create_group"?`Created “${s.groupName}” with ${s.tabCount} tab${s.tabCount===1?"":"s"}`:s.action==="add_to_group"?`Moved ${s.tabCount} tab${s.tabCount===1?"":"s"} into “${s.groupName}”`:s.action==="update_group"?s.previousName&&s.previousName!==s.groupName?`Renamed “${s.previousName}” to “${s.groupName}”`:`Updated “${s.groupName}”`:s.action==="ungroup"?`Ungrouped ${s.tabCount} tab${s.tabCount===1?"":"s"} from ${s.groupCount} group${s.groupCount===1?"":"s"}`:s.action==="remove_duplicates"?s.closedCount?`Closed ${s.closedCount} duplicate tab${s.closedCount===1?"":"s"}`:"No duplicate tabs found":s.action==="merge_groups"?`Merged ${s.groupCount} groups into “${s.groupName}” · ${s.tabCount} tabs`:s.reply}),s.action==="answer"&&typeof s.tabId=="number"&&r.jsxs("button",{onClick:()=>N(s.tabId),className:"flex shrink-0 items-center gap-1 rounded border border-border px-1.5 py-0.5 text-[11px] text-foreground transition-colors hover:bg-muted",children:["Go to tab ",r.jsx(ea,{className:"size-3"})]})]}),s?.action==="remove_duplicates"&&s.closedTabs&&s.closedTabs.length>0&&r.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"mt-2 max-h-32 space-y-1.5 overflow-y-auto rounded-md border border-border bg-muted/20 p-2 text-xs",children:s.closedTabs.map((x,y)=>r.jsxs("li",{className:"min-w-0",children:[r.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:x.title||"Untitled tab"}),r.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:x.url})]},`${x.url}-${y}`))})]})}const Fe={collecting:{label:"Reading titles",progress:18},classifying:{label:"Finding themes",progress:48},reading:{label:"Reading ambiguous pages",progress:68},applying:{label:"Creating tab groups",progress:88}};function ir({job:o}){const e=Fe[o?.stage||"collecting"]??Fe.collecting,a=o?.tabCount||0;return r.jsxs("section",{className:"mt-6","aria-live":"polite","aria-label":`${e.label}. Organizing tabs.`,children:[r.jsx("h1",{className:"text-xl font-semibold tracking-tight",children:a?`Organizing ${a} tabs`:"Organizing tabs"}),r.jsx("p",{className:"mt-1 text-sm text-muted-foreground",children:e.label}),r.jsxs("div",{className:"tab-rail mt-6","aria-hidden":"true",children:[r.jsx("div",{className:"tab-rail-line"}),[0,1,2,3].map(t=>r.jsx("span",{className:"tab-rail-item",style:{animationDelay:`${t*-.58}s`},children:r.jsx("span",{className:"tab-rail-notch"})},t)),r.jsx("span",{className:"tab-rail-arrow",children:"→"}),r.jsxs("span",{className:"tab-rail-groups",children:[r.jsx("span",{}),r.jsx("span",{})]})]}),r.jsxs("div",{className:"mt-5 flex items-center justify-between gap-3 text-xs",children:[r.jsx("span",{className:"text-muted-foreground",children:e.label}),r.jsxs("span",{className:"tabular-nums text-foreground",children:[e.progress,"%"]})]}),r.jsx("div",{className:"mt-2 h-0.5 overflow-hidden rounded-full bg-muted",children:r.jsx("div",{className:"organize-progress h-full origin-left bg-primary transition-transform duration-500 [transition-timing-function:var(--ease-out-strong)]",style:{transform:`scaleX(${e.progress/100})`}})}),r.jsxs("div",{className:"mt-6 flex items-center gap-2 border-t border-border pt-4 text-xs text-muted-foreground",children:[r.jsx(xa,{className:"size-4 text-primary"}),r.jsx("span",{children:"Safe to close — progress continues"})]})]})}function nr({onDismiss:o}){return r.jsx("section",{className:"mt-4 rounded-lg border border-primary/35 bg-primary/10 p-3","aria-live":"polite",children:r.jsxs("div",{className:"flex items-start gap-2.5",children:[r.jsx(ca,{className:"mt-0.5 size-4 shrink-0 text-primary"}),r.jsxs("div",{className:"min-w-0 flex-1",children:[r.jsx("p",{className:"text-sm font-medium leading-snug",children:"Pin Focused to your toolbar"}),r.jsxs("p",{className:"mt-1 text-xs leading-snug text-muted-foreground",children:["Click the ",r.jsx(pa,{className:"inline size-3.5 align-[-2px]","aria-label":"puzzle-piece"})," icon next to the address bar, then hit the pin beside Focused so it’s always one click away."]}),r.jsx("div",{className:"mt-2",children:r.jsx(We,{onClick:o,variant:"ghost",size:"sm",children:"Got it"})})]})]})})}function lr({groups:o,selected:e,applying:a,onSelectedChange:t,onApply:n,onDiscard:c}){return r.jsxs("section",{className:"mt-5",children:[r.jsxs("div",{className:"mb-3",children:[r.jsx("h1",{className:"text-base font-semibold tracking-tight",children:"Review groups"}),r.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:"Choose which suggestions to create."})]}),r.jsx("div",{className:"flex max-h-72 flex-col gap-1 overflow-y-auto",children:o.map((d,p)=>r.jsxs("label",{className:"review-item flex cursor-pointer items-start gap-2.5 rounded-md p-2 hover:bg-accent",style:{animationDelay:`${p*40}ms`},children:[r.jsx(Ue,{className:"mt-0.5",checked:e.has(p),disabled:a,onCheckedChange:m=>{const g=new Set(e);m?g.add(p):g.delete(p),t(g)}}),r.jsxs("span",{className:"min-w-0",children:[r.jsxs("span",{className:"block text-sm font-medium leading-tight",children:[d.name,r.jsx("span",{className:"ml-1.5 font-normal text-muted-foreground",children:d.tabIds.length})]}),r.jsx("span",{className:"block truncate text-xs text-muted-foreground",children:d.tabTitles.join(" · ")})]})]},`${d.existingGroupId??"new"}-${p}`))}),r.jsxs("div",{className:"mt-3 flex gap-2",children:[r.jsx(We,{onClick:c,disabled:a,variant:"outline",className:"flex-1",size:"sm",children:"Discard"}),r.jsxs(We,{onClick:n,disabled:!e.size||a,className:"flex-1",size:"sm",children:[a?r.jsx(me,{className:"size-4 animate-spin"}):null,a?"Applying…":"Apply selected"]})]})]})}const ye={grey:"bg-zinc-400",blue:"bg-blue-500",red:"bg-red-500",yellow:"bg-yellow-400",green:"bg-green-500",pink:"bg-pink-500",purple:"bg-purple-500",cyan:"bg-cyan-500",orange:"bg-orange-500"};function Re(o){const e=o.loadedCount??o.tabCount;return e>=7?{label:"high",className:"text-orange-400"}:e>=3?{label:"med",className:"text-yellow-500"}:{label:"low",className:"text-muted-foreground"}}function cr(o){const e=Math.max(0,Math.round((Date.now()-o)/6e4));if(e<1)return"just now";if(e<60)return`${e}m ago`;const a=Math.round(e/60);return a<24?`${a}h ago`:`${Math.round(a/24)}d ago`}function dr({groups:o,stashes:e,busyId:a,disabled:t,onStash:n,onResume:c,onDelete:d}){const[p,m]=b.useState(!1),[g,h]=b.useState(null);return!o.length&&!e.length?null:r.jsxs(r.Fragment,{children:[o.length>0&&r.jsxs("section",{className:"mt-4","aria-label":"Tab groups in this window",children:[r.jsxs("button",{type:"button",onClick:()=>m(l=>!l),"aria-expanded":p,"aria-controls":"groups-list",className:"flex h-7 w-full items-center justify-between rounded-md px-1.5 outline-none transition-colors hover:bg-muted/50 focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsxs("span",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:["Groups · ",o.length]}),r.jsx(Ie,{className:`size-3.5 text-muted-foreground transition-transform duration-200 [transition-timing-function:var(--ease-out-strong)] ${p?"rotate-180":""}`})]}),p&&r.jsx("div",{id:"groups-list",className:"mt-1 flex flex-col",children:o.map(l=>r.jsxs("div",{className:"flex h-8 items-center gap-2 rounded-md px-1.5 hover:bg-muted/50",children:[r.jsx("span",{className:`size-2 shrink-0 rounded-full ${ye[l.color]??ye.grey}`}),r.jsx("span",{className:"min-w-0 flex-1 truncate text-xs",children:l.title}),r.jsx("span",{title:`Approximate memory use: ${l.loadedCount??l.tabCount} of ${l.tabCount} tabs loaded`,className:`text-[10px] font-medium uppercase tracking-wide ${Re(l).className}`,children:Re(l).label}),r.jsx("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:l.tabCount}),r.jsx(Ne,{title:`Stash “${l.title}”`,disabled:t,onClick:()=>n(l.id),children:a===l.id?r.jsx(me,{className:"size-3.5 animate-spin"}):r.jsx(Ke,{className:"size-3.5"})})]},l.id))})]}),e.length>0&&r.jsxs("section",{className:"mt-4","aria-label":"Stashed groups",children:[r.jsx("h2",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:"Stashed"}),r.jsx("div",{className:"mt-1.5 flex flex-col gap-1",children:e.map(l=>{const s=l.resumeStatus==="resuming",f=t||s;return r.jsxs("div",{className:"rounded-md border border-border/70 px-2 py-1.5",children:[r.jsxs("div",{className:"flex items-center gap-2",children:[r.jsx("span",{className:`size-2 shrink-0 rounded-full ${ye[l.color]??ye.grey}`}),r.jsx("span",{className:"min-w-0 flex-1 truncate text-xs font-medium",children:l.name}),g===l.id?r.jsxs(r.Fragment,{children:[r.jsx("span",{className:"text-[11px] text-destructive",children:"Delete this stash?"}),r.jsx("button",{type:"button",onClick:()=>h(null),className:"rounded px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"Cancel"}),r.jsx("button",{type:"button",disabled:f,onClick:async()=>{await d(l.id),h(null)},className:"rounded bg-destructive/10 px-1.5 py-0.5 text-[11px] font-medium text-destructive outline-none transition-colors hover:bg-destructive/20 focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:"Delete"})]}):r.jsxs(r.Fragment,{children:[r.jsxs("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:[l.tabCount," · ",cr(l.createdAt)]}),r.jsx(Ne,{title:"Resume",disabled:f,onClick:()=>c(l.id),children:a===l.id||s?r.jsx(me,{className:"size-3.5 animate-spin"}):r.jsx(Je,{className:"size-3.5"})}),r.jsx(Ne,{title:"Delete stash",disabled:f,onClick:()=>h(l.id),children:r.jsx(wa,{className:"size-3.5"})})]})]}),s?r.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Resuming this stash…"}):l.briefStatus==="pending"?r.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Writing where-you-left-off brief…"}):l.brief?r.jsx("p",{className:"mt-1 line-clamp-3 pl-4 text-[11px] leading-snug text-muted-foreground",children:l.brief}):null]},l.id)})})]})]})}function Ne({title:o,disabled:e,onClick:a,children:t}){return r.jsx("button",{title:o,"aria-label":o,disabled:e,onClick:a,className:"flex size-6 shrink-0 items-center justify-center rounded text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:t})}const pr=typeof window<"u"&&new URLSearchParams(window.location.search).has("overlay"),_e=typeof window<"u"&&window.self!==window.top;function br(){const[o,e]=b.useState(null),[a,t]=b.useState(null),[n,c]=b.useState(null),[d,p]=b.useState([]),[m,g]=b.useState(new Set),[h,l]=b.useState(1),[s,f]=b.useState(),[j,$]=b.useState(1),[w,H]=b.useState(!1),[N,x]=b.useState(!1),[y,v]=b.useState(null),[z,Y]=b.useState(!1),[k,O]=b.useState(!1),[M,X]=b.useState([]),[T,ce]=b.useState([]),[P,D]=b.useState(null),[de,A]=b.useState(null),[C,_]=b.useState([]),[V,pe]=b.useState(_e?null:!0),U=b.useRef(!1),I=b.useRef(null);b.useEffect(()=>{if(!_e)return;let i=!1;return chrome.runtime.sendMessage({type:"overlayHandshake"}).then(u=>{i||pe(u?.allowed===!0)}).catch(()=>{i||pe(!1)}),()=>{i=!0}},[]);const L=b.useCallback(async(i=s)=>{if(!i)return;const u=await chrome.runtime.sendMessage({type:"hasUndo",windowId:i});H(!!u?.hasUndo)},[s]),G=b.useCallback(async()=>{const i=await chrome.runtime.sendMessage({type:"windowCount"});i?.count&&$(i.count)},[]);b.useEffect(()=>{const i=()=>{G().catch(()=>{})};return chrome.windows.onCreated?.addListener(i),chrome.windows.onRemoved.addListener(i),()=>{chrome.windows.onCreated?.removeListener(i),chrome.windows.onRemoved.removeListener(i)}},[G]);const S=b.useCallback(async()=>{if(!s)return;const[i,u]=await Promise.all([chrome.runtime.sendMessage({type:"listGroups",windowId:s}),chrome.runtime.sendMessage({type:"listStashes",windowId:s})]);i?.groups&&X(i.groups),u?.stashes&&ce(u.stashes)},[s]);b.useEffect(()=>{S();const i=(u,q)=>{q==="local"&&u.stashes&&S()};return chrome.storage.onChanged.addListener(i),()=>chrome.storage.onChanged.removeListener(i)},[S]);const se=b.useCallback(async i=>{!s||!i||(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:s,jobId:i}),c(null))},[s]),ae=b.useCallback(async(i,u)=>{if(u&&I.current===u)return;u&&(I.current=u),e(null),await L();const q=Array.isArray(i?.closedTabs)?i.closedTabs:[];if(!i||i.error){_([]),t({text:i?.error??"Something went wrong.",error:!0,closedTabs:q}),await se(u);return}if(i.review&&i.groups){_(q),p(i.groups),g(new Set(i.groups.map((Z,ge)=>ge))),l(i.minSize||1),t(null);return}_([]),t({text:`${i.groupCount} group${i.groupCount===1?"":"s"} · ${i.tabCount} tabs sorted`,closedTabs:q}),await se(u),await S()},[se,L,S]);b.useEffect(()=>{(async()=>{const i=await chrome.windows.getCurrent(),[u,q,Z]=await Promise.all([chrome.runtime.sendMessage({type:"hasUndo",windowId:i.id}),chrome.runtime.sendMessage({type:"windowCount"}),chrome.storage.local.get({dataNoticeAck:!1,pinPromptDismissed:!1})]);try{const ge=await chrome.action.getUserSettings();x(!ge.isOnToolbar&&!Z.pinPromptDismissed)}catch{}f(i.id),q?.count&&$(q.count),H(!!u?.hasUndo),v(!!Z.dataNoticeAck)})()},[]);const ke=o==="organize"||n?.status==="running";b.useEffect(()=>{if(!s)return;let i=!1,u;const q=async()=>{let Z=!1;try{const ge=await chrome.runtime.sendMessage({type:"organizeStatus",windowId:s});if(i)return;const ee=ge?.job;ee?.status==="running"?(c(ee),e("organize"),t(null),Z=!0):ee&&!U.current&&I.current!==ee.id&&(c(ee),await ae(ee.result||{error:ee.error},ee.id))}catch{}!i&&Z&&(u=window.setTimeout(q,450))};return q(),()=>{i=!0,u&&window.clearTimeout(u)}},[ae,s,ke]);const je=async()=>{if(!y&&!z){Y(!0),t({text:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider."});return}z&&(Y(!1),v(!0),await chrome.storage.local.set({dataNoticeAck:!0})),e("organize"),t(null),_([]),I.current=null,U.current=!0;let i=await chrome.permissions.contains({origins:["<all_urls>"]});if(!i)try{i=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{i=!1}try{const u=await chrome.runtime.sendMessage({type:"organize",hasContentPermission:i,windowId:s});if(U.current=!1,u?.running&&u.job){c(u.job);return}await ae(u,u?.jobId)}catch{U.current=!1,e(null),t({text:"Organizing was interrupted. Try again.",error:!0})}},W=async()=>{const i=n?.id??I.current??void 0;try{if(s&&i&&!(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:s,jobId:i}))?.cleared){t({text:"Couldn't discard the suggestions — try again.",error:!0});return}p([]),g(new Set),c(null),t({text:C.length?`Suggestions discarded · ${C.length} duplicate tab${C.length===1?"":"s"} closed`:"Suggestions discarded.",closedTabs:C}),_([])}catch{t({text:"Couldn't discard the suggestions — try again.",error:!0})}},F=async()=>{const i=d.filter((q,Z)=>m.has(Z));if(!i.length)return;e("apply");const u=await chrome.runtime.sendMessage({type:"applyPlan",groups:i,minSize:h,windowId:s});e(null),p([]),await Promise.all([L(),S()]),await se(n?.id??I.current??void 0),t(u?.error?{text:u.error,error:!0,closedTabs:C}:{text:`${u.groupCount} group${u.groupCount===1?"":"s"} created`,closedTabs:C}),_([])},B=async()=>{e("ungroup"),t(null);const i=await chrome.runtime.sendMessage({type:"ungroupAll",windowId:s});e(null),await Promise.all([L(),S()]),t(i?.error?{text:i.error,error:!0}:{text:`${i.tabCount} tab${i.tabCount===1?"":"s"} ungrouped`})},J=async()=>{e("duplicates"),t(null);const i=await chrome.runtime.sendMessage({type:"cleanDuplicates",windowId:s});e(null),await Promise.all([L(),S()]),t(i?.error?{text:i.error,error:!0}:{text:i.closedCount?`Closed ${i.closedCount} duplicate tab${i.closedCount===1?"":"s"}`:"No duplicate tabs found",closedTabs:Array.isArray(i.closedTabs)?i.closedTabs:[]})},be=async()=>{e("merge"),t(null);const i=await chrome.runtime.sendMessage({type:"mergeWindows",windowId:s});if(e(null),i?.error){t({text:i.error,error:!0});return}await Promise.all([G(),S()]),t({text:`Merged ${i.windows} window${i.windows===1?"":"s"} · ${i.tabs} tabs`})},Q=async()=>{e("undo"),t(null);const i=await chrome.runtime.sendMessage({type:"undo",windowId:s});if(e(null),await Promise.all([L(),S()]),i?.error){t({text:i.error,error:!0});return}t({text:i?.skippedCount?`Restored the available layout — ${i.skippedCount} tab${i.skippedCount===1?"":"s"} closed since couldn't be brought back`:"Previous tab layout restored"})},ue=b.useCallback(async()=>{v(!0),await chrome.storage.local.set({dataNoticeAck:!0})},[]),xe=async i=>{if(!y){if(de!==i){A(i),t({text:"Stash briefs send tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Click again to continue."});return}A(null),await ue()}D(i),t(null);let u;try{u=await chrome.runtime.sendMessage({type:"stashGroup",windowId:s,groupId:i})}finally{D(null)}await S(),t(u?.error?{text:u.error,error:!0}:{text:`Stashed “${u.stash?.name}” · ${u.stash?.tabCount} tabs`})},he=async i=>{D(i),t(null);let u;try{u=await chrome.runtime.sendMessage({type:"resumeStash",stashId:i,windowId:s})}finally{D(null)}await S(),t(u?.error?{text:u.error,error:!0}:{text:`Restored ${u.tabCount} tab${u.tabCount===1?"":"s"}`})},ie=async i=>{const u=await chrome.runtime.sendMessage({type:"deleteStash",stashId:i});await S(),t(u?.error?{text:u.error,error:!0}:{text:"Stash deleted"})},re=d.length>0,ne=o==="organize"||n?.status==="running",E=!!o||re||P!==null||k||y===null||s===void 0,K=(i,u)=>o===i?r.jsx(me,{className:"size-4 animate-spin"}):u;return V===null?null:V===!1?r.jsx("main",{className:"popup-shell w-[340px] p-4",children:r.jsx("p",{className:"text-xs text-muted-foreground",children:"Open Focused from the toolbar icon to use it here."})}):r.jsx(He,{size:"md",colorVariant:"ocean",theme:"dark",strength:.45,borderRadius:pr?16:0,active:ne||k,className:"popup-frame","data-testid":"window-beam",children:r.jsxs("main",{className:"popup-shell w-[340px] p-4",children:[r.jsxs("header",{className:"flex items-center justify-between",children:[r.jsxs("div",{className:"flex items-center gap-2.5",children:[r.jsx("span",{className:"flex size-8 items-center justify-center rounded-md border border-border bg-muted/50 text-foreground",children:r.jsx("img",{src:"icons/icon48.png",alt:"",className:"size-5 rounded-[5px]"})}),r.jsx("span",{className:"text-sm font-semibold tracking-tight",children:"Focused"})]}),r.jsx("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"flex size-8 items-center justify-center rounded-md border border-transparent text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted hover:text-foreground active:scale-[0.96] focus-visible:ring-2 focus-visible:ring-ring",title:"Settings","aria-label":"Settings",children:r.jsx(ma,{className:"size-4"})})]}),ne?r.jsx(ir,{job:n}):re||o==="apply"?r.jsx(lr,{groups:d,selected:m,applying:o==="apply",onSelectedChange:g,onApply:F,onDiscard:W}):r.jsxs(r.Fragment,{children:[N&&r.jsx(nr,{onDismiss:()=>{x(!1),chrome.storage.local.set({pinPromptDismissed:!0})}}),r.jsx(sr,{windowId:s,disabled:E&&!k,acknowledged:y===!0,onAcknowledge:ue,onRunningChange:O,onMutation:async()=>{await Promise.all([L(),S()])}}),r.jsx(He,{size:"md",colorVariant:"ocean",theme:"dark",strength:.4,active:z,className:"mt-3 w-full has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-ring","data-testid":"organize-beam",children:r.jsxs("button",{onClick:je,disabled:E,className:"flex h-20 w-full flex-col items-center justify-center gap-2 rounded-lg border border-border bg-transparent text-sm font-medium text-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary/50 hover:bg-muted active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40","aria-label":"Organize tabs",children:[r.jsx($a,{className:"size-5 text-primary"}),r.jsx("span",{children:z?"Continue organizing":"Organize tabs"})]})}),r.jsxs("div",{className:"mt-3 grid grid-cols-2 gap-2",children:[r.jsx(ve,{label:"Ungroup",onClick:B,disabled:E,icon:K("ungroup",r.jsx(or,{className:"size-[18px]"}))}),r.jsx(ve,{label:"Close duplicates",onClick:J,disabled:E,icon:K("duplicates",r.jsx(oa,{className:"size-4"}))}),r.jsx(ve,{label:"Merge windows",onClick:be,disabled:E||j<=1,icon:K("merge",r.jsx(ra,{className:"size-4"}))}),r.jsx(ve,{label:"Undo",onClick:Q,disabled:E||!w,icon:K("undo",r.jsx(va,{className:"size-4"}))})]}),r.jsx(dr,{groups:M,stashes:T,busyId:P,disabled:E,onStash:xe,onResume:he,onDelete:ie})]}),!ne&&r.jsxs(r.Fragment,{children:[r.jsxs("div",{className:"mt-4 min-h-4 text-xs","aria-live":"polite",children:[r.jsx("p",{className:a?.error?"text-destructive":"text-muted-foreground",children:a?.text??""}),a?.closedTabs&&a.closedTabs.length>0&&r.jsxs("div",{className:"closed-toast relative mt-2 overflow-hidden rounded-md border border-border bg-muted/20",children:[r.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"max-h-36 space-y-1.5 overflow-y-auto p-2 pb-2.5",children:a.closedTabs.map((i,u)=>r.jsxs("li",{className:"flex min-w-0 items-center gap-2",children:[r.jsxs("div",{className:"min-w-0 flex-1",children:[r.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:i.title||"Untitled tab"}),r.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:i.url})]}),i.keptTabId!==void 0&&r.jsx("button",{type:"button",onClick:()=>chrome.runtime.sendMessage({type:"focusTab",tabId:i.keptTabId}),className:"shrink-0 rounded border border-border px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"View existing"})]},`${i.url}-${u}`))}),r.jsx("div",{"data-testid":"closed-toast-timer",className:"closed-toast-timer absolute inset-x-0 bottom-0 h-0.5 origin-left bg-primary/60",onAnimationEnd:()=>t(null)})]})]}),r.jsxs("a",{href:"mailto:prithvi@skive.in?subject=Focused%20feature%20request&body=Hi%20Prithvi%2C%0A%0AI%27d%20like%20to%20request%3A%0A%0A",className:"mt-2 flex h-8 w-full items-center justify-center gap-1.5 rounded-md border border-transparent text-xs text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted/50 hover:text-foreground active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsx(na,{className:"size-3.5"}),"Request a feature"]})]})]})})}function ve({label:o,icon:e,onClick:a,disabled:t}){return r.jsxs("button",{onClick:a,disabled:t,className:"flex h-16 flex-col items-center justify-center gap-1.5 rounded-lg border border-border bg-transparent text-xs text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:bg-muted hover:text-foreground active:scale-[0.97] focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:[e,r.jsx("span",{className:"px-1 text-center leading-tight",children:o})]})}if(new URLSearchParams(window.location.search).has("overlay")){document.documentElement.dataset.overlay="";const o=()=>window.parent.postMessage({__focusedOverlay:!0,height:document.body.scrollHeight},"*");new ResizeObserver(o).observe(document.body),window.addEventListener("keydown",e=>{e.key==="Escape"&&window.parent.postMessage({__focusedOverlay:!0,close:!0},"*")})}Ve.createRoot(document.getElementById("root")).render(r.jsx(Ge.StrictMode,{children:r.jsx(br,{})}));
